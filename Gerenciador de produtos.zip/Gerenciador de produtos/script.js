class Produto {
    constructor(nome, preco, categoria) {
      this.nome = nome;
      this.preco = parseFloat(preco);
      this.categoria = categoria;
    }
  
    detalhes() {
      return `Produto: ${this.nome} | Preço: R$${this.preco.toFixed(2)} | Categoria: ${this.categoria}`;
    }
  }
  
  const listaProdutos = [];
  
  function adicionarProduto() {
    const nome = document.getElementById('nome').value;
    const preco = document.getElementById('preco').value;
    const categoria = document.getElementById('categoria').value;
  
    if (nome && preco && categoria) {
      const produto = new Produto(nome, preco, categoria);
      listaProdutos.push(produto);
      mostrarResultado('Produto adicionado com sucesso!');
      limparCampos();
    } else {
      mostrarResultado('Preencha todos os campos.');
    }
  }
  
  function buscarProduto() {
    const nomeBusca = document.getElementById('buscaNome').value;
    const encontrado = listaProdutos.find(p => p.nome.toLowerCase() === nomeBusca.toLowerCase());
  
    if (encontrado) {
      mostrarResultado(encontrado.detalhes());
    } else {
      mostrarResultado('Produto não encontrado.');
    }
  }
  
  function listarProdutos() {
    if (listaProdutos.length === 0) return mostrarResultado('Nenhum produto cadastrado.');
  
    let resultado = 'Lista de Produtos:\n';
    listaProdutos.forEach(p => {
      resultado += p.detalhes() + '\n';
    });
    mostrarResultado(resultado);
  }
  
  function filtrarPorCategoria() {
    const categoriaFiltro = document.getElementById('filtroCategoria').value;
    const filtrados = listaProdutos.filter(p => p.categoria.toLowerCase() === categoriaFiltro.toLowerCase());
  
    if (filtrados.length === 0) return mostrarResultado('Nenhum produto nessa categoria.');
  
    let resultado = `Produtos da categoria '${categoriaFiltro}':\n`;
    filtrados.forEach(p => resultado += p.detalhes() + '\n');
    mostrarResultado(resultado);
  }
  
  function resumoEstatistico() {
    if (listaProdutos.length === 0) return mostrarResultado('Nenhum produto para calcular.');
  
    const total = listaProdutos.reduce((acc, p) => acc + p.preco, 0);
    mostrarResultado(`Total de produtos: ${listaProdutos.length}\nSoma dos preços: R$${total.toFixed(2)}`);
  }
  
  function mostrarResultado(msg) {
    const resultado = document.getElementById('resultado');
    resultado.innerText = msg;
    resultado.classList.add('show');
}
