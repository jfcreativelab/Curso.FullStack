// Variável global que armazenará a lista de livros
let books = JSON.parse(localStorage.getItem('books')) || [];

// Função para salvar os livros no localStorage
function saveBooks() {
  localStorage.setItem('books', JSON.stringify(books));
}

// Função para renderizar a lista de livros
function renderBooks(list = books) {
  const container = document.getElementById('books-container');
  container.innerHTML = '';

  if (list.length === 0) {
    container.innerHTML = '<p style="text-align: center;">Nenhum livro cadastrado.</p>';
    return;
  }

  list.forEach((book, index) => {
    // Cria o elemento card para o livro
    const card = document.createElement('div');
    card.className = 'book-card';

    // Imagem de capa (se não houver URL, utiliza placeholder)
    const image = document.createElement('img');
    image.className = 'book-image';
    image.src = book.image || 'https://via.placeholder.com/80x110?text=Sem+Capa';
    image.alt = `${book.title} - capa`;

    // Informações do livro
    const info = document.createElement('div');
    info.className = 'book-info';
    info.innerHTML = `
      <p><strong>${book.title}</strong></p>
      <p>Autor: ${book.author}</p>
      <p>Gênero: ${book.genre}</p>
      <p>Ano: ${book.year}</p>
      <p>Avaliação: ${book.rating}/5</p>
    `;

    // Botões de controle: avaliar e remover
    const controls = document.createElement('div');
    controls.className = 'control-buttons';

    // Input para nova avaliação
    const inputEval = document.createElement('input');
    inputEval.type = 'number';
    inputEval.min = '0';
    inputEval.max = '5';
    inputEval.step = '0.1';
    inputEval.className = 'input-evaluate';
    inputEval.placeholder = 'Nova nota';

    // Botão para atualizar avaliação
    const btnEval = document.createElement('button');
    btnEval.className = 'btn-evaluate';
    btnEval.textContent = 'Atualizar Avaliação';
    btnEval.addEventListener('click', () => {
      const newRating = parseFloat(inputEval.value);
      if (!isNaN(newRating) && newRating >= 0 && newRating <= 5) {
        books[index].rating = newRating;
        saveBooks();
        renderBooks();
      } else {
        alert('Digite uma nota válida entre 0 e 5.');
      }
    });

    // Botão para remover livro
    const btnRemove = document.createElement('button');
    btnRemove.className = 'btn-remove';
    btnRemove.textContent = 'Remover';
    btnRemove.addEventListener('click', () => {
      if(confirm(`Remover o livro "${book.title}"?`)){
        books.splice(index, 1);
        saveBooks();
        renderBooks();
      }
    });

    controls.appendChild(inputEval);
    controls.appendChild(btnEval);
    controls.appendChild(btnRemove);

    // Adiciona os elementos ao card
    card.appendChild(image);
    card.appendChild(info);
    card.appendChild(controls);

    container.appendChild(card);
  });
}

// Função para adicionar um novo livro
function addBook(e) {
  e.preventDefault();
  
  const title = document.getElementById('title').value.trim();
  const author = document.getElementById('author').value.trim();
  const genre = document.getElementById('genre').value.trim();
  const year = parseInt(document.getElementById('year').value);
  const rating = parseFloat(document.getElementById('rating').value);
  const image = document.getElementById('image').value.trim();

  if (!title || !author || !genre || isNaN(year) || isNaN(rating) || rating < 0 || rating > 5) {
    alert('Preencha todos os campos corretamente!');
    return;
  }

  const newBook = { title, author, genre, year, rating, image };
  books.push(newBook);
  saveBooks();
  renderBooks();

  document.getElementById('book-form').reset();
}

// Função para buscar livros conforme termo digitado
function searchBooks() {
  const term = document.getElementById('search-input').value.toLowerCase();
  const filtered = books.filter(book => 
    book.title.toLowerCase().includes(term) ||
    book.author.toLowerCase().includes(term) ||
    book.genre.toLowerCase().includes(term)
  );
  renderBooks(filtered);
}

// Função para classificar livros por título, autor ou avaliação
function sortBooks() {
  const criterion = document.getElementById('sort-select').value;
  if (criterion) {
    books.sort((a, b) => {
      if (criterion === 'rating') {
        return b.rating - a.rating;
      } else {
        return a[criterion].toLowerCase().localeCompare(b[criterion].toLowerCase());
      }
    });
    renderBooks();
  }
}

// Eventos dos elementos
document.getElementById('book-form').addEventListener('submit', addBook);
document.getElementById('search-input').addEventListener('input', searchBooks);
document.getElementById('sort-select').addEventListener('change', sortBooks);

// Carrega os livros quando a página é inicializada
document.addEventListener('DOMContentLoaded', renderBooks);
