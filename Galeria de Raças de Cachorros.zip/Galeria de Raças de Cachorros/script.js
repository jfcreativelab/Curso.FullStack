const urlLista = "https://dog.ceo/api/breeds/list/all";
const urlImagens = (raca) => `https://dog.ceo/api/breed/${raca}/images/random/4`;

const botoesContainer = document.getElementById("botoes-racas");
const imagensContainer = document.getElementById("imagens");

// Busca todas as raças e cria os botões
fetch(urlLista)
  .then(response => response.json())
  .then(data => {
    const racas = Object.keys(data.message);
    racas.forEach(raca => {
      const botao = document.createElement("button");
      botao.textContent = raca.charAt(0).toUpperCase() + raca.slice(1);
      botao.addEventListener("click", () => carregarImagens(raca));
      botoesContainer.appendChild(botao);
    });
  })
  .catch(error => {
    alert("Erro ao carregar raças de cachorro.");
    console.error("Erro:", error);
  });

// Carrega e exibe as imagens
function carregarImagens(raca) {
  imagensContainer.innerHTML = "<p>Carregando imagens...</p>";
  fetch(urlImagens(raca))
    .then(response => response.json())
    .then(data => {
      imagensContainer.innerHTML = "";
      data.message.forEach(imagem => {
        const card = document.createElement("div");
        card.classList.add("card-imagem");

        const img = document.createElement("img");
        img.src = imagem;
        img.alt = `Imagem da raça ${raca}`;

        card.appendChild(img);
        imagensContainer.appendChild(card);
      });
    })
    .catch(error => {
      imagensContainer.innerHTML = "<p>Erro ao carregar imagens.</p>";
      console.error("Erro:", error);
    });
}
