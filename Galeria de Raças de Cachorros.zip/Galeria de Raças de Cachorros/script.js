const urlLista = "https://dog.ceo/api/breeds/list/all";
const urlImagens = (raca) => `https://dog.ceo/api/breed/${raca}/images/random/4`;

const botoesContainer = document.getElementById("botoes-racas");
const imagensContainer = document.getElementById("imagens");

// Inicialização da galeria
async function carregarRacas() {
  try {
    const resposta = await fetch(urlLista);
    if (!resposta.ok) throw new Error("Não foi possível obter a lista de raças.");
    
    const dados = await resposta.json();
    const racas = Object.keys(dados.message);

    racas.forEach(raca => {
      const botao = document.createElement("button");
      botao.textContent = raca.charAt(0).toUpperCase() + raca.slice(1);
      botao.addEventListener("click", () => {
        destacarBotaoSelecionado(botao);
        carregarImagens(raca);
      });
      botoesContainer.appendChild(botao);
    });
  } catch (erro) {
    alert("Erro ao carregar as raças. Tente novamente mais tarde.");
    console.error("Detalhes do erro:", erro);
  }
}

async function carregarImagens(raca) {
  imagensContainer.innerHTML = "<p>🔄 Carregando imagens...</p>";
  try {
    const resposta = await fetch(urlImagens(raca));
    if (!resposta.ok) throw new Error("Falha ao buscar as imagens.");

    const dados = await resposta.json();
    imagensContainer.innerHTML = "";

    dados.message.forEach(imagem => {
      const card = document.createElement("div");
      card.classList.add("card-imagem");

      const img = document.createElement("img");
      img.src = imagem;
      img.alt = `Imagem da raça ${raca}`;

      card.appendChild(img);
      imagensContainer.appendChild(card);
    });
  } catch (erro) {
    imagensContainer.innerHTML = "<p>❌ Não foi possível carregar as imagens. Tente novamente.</p>";
    console.error("Erro ao buscar imagens:", erro);
  }
}

function destacarBotaoSelecionado(botaoAtual) {
  const botoes = document.querySelectorAll(".container-botoes button");
  botoes.forEach(btn => btn.classList.remove("selecionado"));
  botaoAtual.classList.add("selecionado");
}

// Alternância de modo escuro
const botaoTema = document.getElementById("toggle-tema");
botaoTema.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  botaoTema.textContent = document.body.classList.contains("dark")
    ? "☀️ Modo Claro"
    : "🌙 Modo Escuro";
});
// Executar ao carregar a página
carregarRacas();