
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('cadastroForm');

    form.addEventListener('submit', function(event) {
        event.preventDefault();
        clearMessages();

        try {
            const nome = document.getElementById('nome').value.trim();
            const usuario = document.getElementById('usuario').value.trim();
            const email = document.getElementById('email').value.trim();
            const senha = document.getElementById('senha').value.trim();
            const dataNascimento = document.getElementById('dataNascimento').value;

            if (!nome) throw new Error('O campo Nome é obrigatório.');
            if (!usuario) throw new Error('O campo Usuário é obrigatório.');
            if (!email) {
                throw new Error('O campo Email é obrigatório.');
            } else if (!isValidEmail(email)) {
                throw new Error('Por favor, insira um email válido.');
            }
            if (!senha) throw new Error('O campo Senha é obrigatório.');
            if (!dataNascimento) {
                throw new Error('A Data de Nascimento é obrigatória.');
            } else if (!isOfAge(dataNascimento)) {
                throw new Error('Você deve ter pelo menos 18 anos.');
            }

            displaySuccess('Cadastro realizado com sucesso!');
            form.reset(); 

        } catch (error) {
            handleErrors(error.message);
        }
    });

    function handleErrors(message) {
        if (message.includes('Nome')) {
            displayError('nomeError', message);
        } else if (message.includes('Usuário')) {
            displayError('usuarioError', message);
        } else if (message.includes('Email') || message.includes('email')) {
            displayError('emailError', message);
        } else if (message.includes('Senha')) {
            displayError('senhaError', message);
        } else if (message.includes('Nascimento') || message.includes('anos')) {
            displayError('dataNascimentoError', message);
        } else {
            console.error("Erro inesperado:", message);
        }
    }

    function displayError(elementId, message) {
        const errorElement = document.getElementById(elementId);
        errorElement.textContent = message;
    }

    function displaySuccess(message) {
        const successElement = document.getElementById('successMessage');
        successElement.textContent = message;
        successElement.style.opacity = '1';
    }

    function clearMessages() {
        document.querySelectorAll('.error-message').forEach(el => el.textContent = '');
        const successElement = document.getElementById('successMessage');
        successElement.textContent = '';
        successElement.style.opacity = '0';
    }

    function isValidEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }

    function isOfAge(birthDateString) {
        const birthDate = new Date(birthDateString);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDifference = today.getMonth() - birthDate.getMonth();
        if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age >= 18;
    }
});