/**
 * Módulo de API para comunicação com o TMDb
 */
class TMDbAPI {
    /**
     * Realiza uma chamada à API do TMDb
     * @param {string} endpoint - Endpoint da API
     * @param {Object} params - Parâmetros adicionais para a chamada
     * @returns {Promise} - Promise com os dados da resposta
     */
    static async fetchAPI(endpoint, params = {}) {
        const url = new URL(`${CONFIG.BASE_URL}${endpoint}`);
        url.searchParams.append('api_key', CONFIG.API_KEY);
        url.searchParams.append('language', CONFIG.LANGUAGE);

        for (const key in params) {
            url.searchParams.append(key, params[key]);
        }

        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`Erro na API: ${response.status} ${response.statusText}`);
            }
            return await response.json();
        } catch (error) {
            console.error('Erro ao acessar a API:', error);
            return null;
        }
    }

    /**
     * Obtém filmes populares
     * @param {number} page - Número da página
     * @returns {Promise} - Promise com os dados dos filmes populares
     */
    static async getPopularMovies(page = 1) {
        return await this.fetchAPI('/movie/popular', { page });
    }
    
    /**
     * Obtém séries populares
     * @param {number} page - Número da página
     * @returns {Promise} - Promise com os dados das séries populares
     */
    static async getPopularTVShows(page = 1) {
        return await this.fetchAPI('/tv/popular', { page });
    }
    
    /**
     * Obtém detalhes de um filme
     * @param {number} movieId - ID do filme
     * @returns {Promise} - Promise com os detalhes do filme
     */
    static async getMovieDetails(movieId) {
        return await this.fetchAPI(`/movie/${movieId}`);
    }
    
    /**
     * Obtém detalhes de uma série
     * @param {number} tvId - ID da série
     * @returns {Promise} - Promise com os detalhes da série
     */
    static async getTVShowDetails(tvId) {
        return await this.fetchAPI(`/tv/${tvId}`);
    }
    
    /**
     * Obtém créditos (elenco e equipe) de um filme
     * @param {number} movieId - ID do filme
     * @returns {Promise} - Promise com os créditos do filme
     */
    static async getMovieCredits(movieId) {
        return await this.fetchAPI(`/movie/${movieId}/credits`);
    }
    
    /**
     * Obtém créditos (elenco e equipe) de uma série
     * @param {number} tvId - ID da série
     * @returns {Promise} - Promise com os créditos da série
     */
    static async getTVShowCredits(tvId) {
        return await this.fetchAPI(`/tv/${tvId}/credits`);
    }
    
    /**
     * Obtém filmes similares a um filme específico
     * @param {number} movieId - ID do filme
     * @returns {Promise} - Promise com os filmes similares
     */
    static async getSimilarMovies(movieId) {
        return await this.fetchAPI(`/movie/${movieId}/similar`);
    }
    
    /**
     * Obtém séries similares a uma série específica
     * @param {number} tvId - ID da série
     * @returns {Promise} - Promise com as séries similares
     */
    static async getSimilarTVShows(tvId) {
        return await this.fetchAPI(`/tv/${tvId}/similar`);
    }
    
    /**
     * Pesquisa filmes
     * @param {string} query - Termo de pesquisa
     * @param {number} page - Número da página
     * @returns {Promise} - Promise com os resultados da pesquisa
     */
    static async searchMovies(query, page = 1) {
        return await this.fetchAPI('/search/movie', { query, page });
    }
    
    /**
     * Pesquisa séries
     * @param {string} query - Termo de pesquisa
     * @param {number} page - Número da página
     * @returns {Promise} - Promise com os resultados da pesquisa
     */
    static async searchTVShows(query, page = 1) {
        return await this.fetchAPI('/search/tv', { query, page });
    }
}
