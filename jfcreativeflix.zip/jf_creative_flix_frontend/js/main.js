/**
 * Módulo de roteamento para navegação SPA
 */
class Router {
    /**
     * Inicializa o router
     */
    static init() {
        // Adicionar evento para navegação interna
        document.addEventListener('click', (e) => {
            if (e.target.tagName === 'A' && e.target.dataset.page) {
                e.preventDefault();
                const page = e.target.dataset.page;
                this.navigateTo(`/${page}`);
            }
        });

        // Adicionar evento para navegação com botão voltar/avançar do navegador
        window.addEventListener('popstate', () => {
            this.handleRoute();
        });

        // Inicializar a rota atual
        this.handleRoute();
    }
    
    /**
     * Navega para uma rota específica
     * @param {string} path - Caminho da rota
     */
    static navigateTo(path) {
        window.history.pushState({}, '', path);
        this.handleRoute();
    }
    
    /**
     * Manipula a rota atual
     */
    static handleRoute() {
        const path = window.location.pathname;
        const searchParams = new URLSearchParams(window.location.search);

        // Atualizar links de navegação ativos
        document.querySelectorAll('nav a').forEach(link => {
            link.classList.remove('active');
            if (link.dataset.page && (path === `/${link.dataset.page}` || (path === '/' && link.dataset.page === 'home'))) {
                link.classList.add('active');
            }
        });

        // Roteamento baseado no caminho
        if (path === '/' || path === '/home') {
            UI.renderHomePage();
        } else if (path === '/movies') {
            const page = parseInt(searchParams.get('page')) || 1;
            UI.renderMoviesPage(page);
        } else if (path === '/series') {
            const page = parseInt(searchParams.get('page')) || 1;
            UI.renderTVShowsPage(page);
        } else if (path === '/search') {
            const query = searchParams.get('q');
            if (query) {
                UI.renderSearchResultsPage(query);
            } else {
                this.navigateTo('/');
            }
        } else {
            // Página não encontrada
            UI.showError('Página não encontrada.');
        }
    }
}

/**
 * Inicialização da aplicação
 */
document.addEventListener('DOMContentLoaded', () => {
    // Inicializar o router
    Router.init();
    
    // Configurar a barra de pesquisa
    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');
    
    const handleSearch = () => {
        const query = searchInput.value.trim();
        if (query) {
            Router.navigateTo(`/search?q=${encodeURIComponent(query)}`);
        }
    };
    
    searchButton.addEventListener('click', handleSearch);
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSearch();
        }
    });
    
    // Criar imagem placeholder para uso posterior
    const placeholderImg = new Image();
    placeholderImg.src = CONFIG.DEFAULT_PLACEHOLDER;
    
    // Verificar se a pasta de imagens existe, caso contrário criar uma imagem placeholder
    fetch(CONFIG.DEFAULT_PLACEHOLDER)
        .catch(() => {
            console.warn('Imagem placeholder não encontrada, criando uma...');
            
            // Criar uma imagem placeholder usando canvas
            const canvas = document.createElement('canvas');
            canvas.width = 300;
            canvas.height = 450;
            const ctx = canvas.getContext('2d');
            
            // Fundo cinza escuro
            ctx.fillStyle = '#333';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Texto "Sem Imagem"
            ctx.fillStyle = '#888';
            ctx.font = 'bold 24px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('Sem Imagem', canvas.width / 2, canvas.height / 2);
            
            // Salvar como blob e criar URL
            canvas.toBlob(blob => {
                CONFIG.DEFAULT_PLACEHOLDER = URL.createObjectURL(blob);
            });
        });
});
