/**
 * Configuração da API do TMDb
 */
const CONFIG = {
    BASE_URL: 'https://api.themoviedb.org/3',
    API_KEY: '225ed74c7bc1ab763b17a9942b7e3e2a', // Substitua pela sua chave
    LANGUAGE: 'pt-BR',
    IMAGE_BASE_URL: 'https://image.tmdb.org/t/p/w500',
    DEFAULT_PLACEHOLDER: 'images/no-image.jpg'
};
