/**
 * Módulo de UI para manipulação da interface do utilizador
 */
class UI {
    /**
     * Processa um item de media (filme ou série) para exibição
     * @param {Object} item - Item de media (filme ou série)
     * @param {string} type - Tipo do item ('movie' ou 'tv')
     * @returns {HTMLElement} - Elemento HTML do item
     */
    static createMediaItem(item, type = 'movie') {
        const mediaItem = document.createElement('div');
        mediaItem.className = 'movie-item';
        mediaItem.dataset.id = item.id;
        mediaItem.dataset.type = type;
        
        // Determinar título com base no tipo
        const title = type === 'movie' ? item.title : (item.name || 'Sem título');
        
        // Verificar se há imagem de poster
        const posterPath = item.poster_path 
            ? `${CONFIG.IMAGE_BASE_URL}${item.poster_path}`
            : CONFIG.DEFAULT_PLACEHOLDER;
        
        // Adicionar classificação se disponível
        const ratingHtml = item.vote_average 
            ? `<div class="rating">${item.vote_average.toFixed(1)}</div>` 
            : '';
        
        mediaItem.innerHTML = `
            ${ratingHtml}
            <img src="${posterPath}" alt="${title} Poster" onerror="this.onerror=null;this.src='${CONFIG.DEFAULT_PLACEHOLDER}';">
            <h3>${title}</h3>
        `;
        
        // Adicionar evento de clique para navegação para detalhes
        mediaItem.addEventListener('click', () => {
            Router.navigateTo(`/${type}/${item.id}`);
        });
        
        return mediaItem;
    }
    
    /**
     * Renderiza uma lista de itens de media em um contentor
     * @param {Array} items - Lista de itens de media
     * @param {string} containerId - ID do contentor HTML
     * @param {string} type - Tipo dos itens ('movie' ou 'tv')
     */
    static renderMediaItems(items, containerId, type) {
        const container = document.getElementById(containerId);
        container.innerHTML = '';

        items.forEach(item => {
            const div = document.createElement('div');
            div.className = 'movie-item';
            div.innerHTML = `
                <img src="${item.poster_path ? CONFIG.IMAGE_BASE_URL + item.poster_path : CONFIG.DEFAULT_PLACEHOLDER}" alt="${item.title || item.name}">
                <h3>${item.title || item.name}</h3>
            `;
            container.appendChild(div);
        });
    }
    
    /**
     * Renderiza a paginação
     * @param {number} currentPage - Página atual
     * @param {number} totalPages - Total de páginas
     * @param {string} containerId - ID do contentor HTML
     * @param {Function} callback - Função de callback para mudança de página
     */
    static renderPagination(currentPage, totalPages, containerId, callback) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        container.innerHTML = '';
        
        // Limitar o número máximo de páginas para evitar sobrecarga
        const maxPages = Math.min(totalPages, 20);
        
        if (currentPage > 1) {
            const prevButton = document.createElement('a');
            prevButton.className = 'page-link';
            prevButton.textContent = '« Anterior';
            prevButton.addEventListener('click', () => callback(currentPage - 1));
            container.appendChild(prevButton);
        }
        
        const currentPageSpan = document.createElement('span');
        currentPageSpan.className = 'current-page';
        currentPageSpan.textContent = `Página ${currentPage} de ${maxPages}`;
        container.appendChild(currentPageSpan);
        
        if (currentPage < maxPages) {
            const nextButton = document.createElement('a');
            nextButton.className = 'page-link';
            nextButton.textContent = 'Próxima »';
            nextButton.addEventListener('click', () => callback(currentPage + 1));
            container.appendChild(nextButton);
        }
    }
    
    /**
     * Exibe mensagem de carregamento
     */
    static showLoading() {
        const main = document.getElementById('main-content');
        main.innerHTML = `
            <div class="loading">
                <div class="spinner"></div>
                <p>A carregar conteúdo...</p>
            </div>
        `;
    }
    
    /**
     * Exibe mensagem de erro
     * @param {string} message - Mensagem de erro
     */
    static showError(message) {
        const main = document.getElementById('main-content');
        main.innerHTML = `
            <div class="error-message">
                <p>${message}</p>
                <button id="retry-button" class="retry-button">Tentar novamente</button>
            </div>
        `;
        
        document.getElementById('retry-button').addEventListener('click', () => {
            window.location.reload();
        });
    }
    
    /**
     * Renderiza a página inicial
     */
    static async renderHomePage() {
        UI.showLoading();
        try {
            const template = document.getElementById('home-template');
            const main = document.getElementById('main-content');
            main.innerHTML = template.innerHTML;

            // Carregar filmes populares
            const popularMoviesData = await TMDbAPI.getPopularMovies();
            if (popularMoviesData && popularMoviesData.results) {
                UI.renderMediaItems(popularMoviesData.results, 'popular-movies', 'movie');
            } else {
                console.error('Nenhum filme encontrado.');
            }
        } catch (error) {
            console.error('Erro ao renderizar a página inicial:', error);
            UI.showError('Não foi possível carregar os filmes.');
        }
    }
    
    /**
     * Renderiza a página de catálogo de filmes
     * @param {number} page - Número da página
     */
    static async renderMoviesPage(page = 1) {
        UI.showLoading();
        
        try {
            // Obter o template da página de filmes
            const template = document.getElementById('movies-template');
            const main = document.getElementById('main-content');
            main.innerHTML = template.innerHTML;
            
            // Carregar filmes populares
            const moviesData = await TMDbAPI.getPopularMovies(page);
            if (moviesData && moviesData.results) {
                UI.renderMediaItems(moviesData.results, 'movies-grid', 'movie');
                
                // Renderizar paginação
                UI.renderPagination(
                    page,
                    moviesData.total_pages,
                    'movies-pagination',
                    (newPage) => Router.navigateTo(`/movies?page=${newPage}`)
                );
            }
        } catch (error) {
            console.error('Erro ao renderizar página de filmes:', error);
            UI.showError('Não foi possível carregar os filmes. Por favor, tente novamente mais tarde.');
        }
    }
    
    /**
     * Renderiza a página de catálogo de séries
     * @param {number} page - Número da página
     */
    static async renderTVShowsPage(page = 1) {
        UI.showLoading();
        
        try {
            // Obter o template da página de séries
            const template = document.getElementById('series-template');
            const main = document.getElementById('main-content');
            main.innerHTML = template.innerHTML;
            
            // Carregar séries populares
            const tvData = await TMDbAPI.getPopularTVShows(page);
            if (tvData && tvData.results) {
                UI.renderMediaItems(tvData.results, 'series-grid', 'tv');
                
                // Renderizar paginação
                UI.renderPagination(
                    page,
                    tvData.total_pages,
                    'series-pagination',
                    (newPage) => Router.navigateTo(`/series?page=${newPage}`)
                );
            }
        } catch (error) {
            console.error('Erro ao renderizar página de séries:', error);
            UI.showError('Não foi possível carregar as séries. Por favor, tente novamente mais tarde.');
        }
    }
    
    /**
     * Renderiza a página de detalhes de um filme
     * @param {number} movieId - ID do filme
     */
    static async renderMovieDetailsPage(movieId) {
        UI.showLoading();
        
        try {
            // Obter o template da página de detalhes
            const template = document.getElementById('movie-details-template');
            const main = document.getElementById('main-content');
            main.innerHTML = template.innerHTML;
            
            // Carregar detalhes do filme
            const movieData = await TMDbAPI.getMovieDetails(movieId);
            if (!movieData) {
                UI.showError('Filme não encontrado.');
                return;
            }
            
            // Adicionar backdrop se disponível
            if (movieData.backdrop_path) {
                const backdropUrl = `${CONFIG.IMAGE_BASE_URL}${movieData.backdrop_path}`;
                const backdropDiv = document.createElement('div');
                backdropDiv.className = 'backdrop';
                backdropDiv.style.backgroundImage = `linear-gradient(to bottom, rgba(20, 20, 20, 0.5) 0%, rgba(20, 20, 20, 1) 100%), url('${backdropUrl}')`;
                
                // Inserir o backdrop antes do conteúdo principal
                const movieDetails = main.querySelector('.movie-details');
                main.insertBefore(backdropDiv, movieDetails);
                
                // Mover os detalhes do filme para dentro do backdrop
                const detailsHeader = main.querySelector('.movie-details-header');
                const detailsContainer = document.createElement('div');
                detailsContainer.className = 'movie-details-container';
                detailsContainer.appendChild(detailsHeader);
                backdropDiv.appendChild(detailsContainer);
            }
            
            // Preencher detalhes do filme
            document.getElementById('detail-title').textContent = movieData.title;
            document.getElementById('detail-overview').textContent = movieData.overview || 'Sem sinopse disponível.';
            
            // Preencher poster
            const posterElement = document.getElementById('detail-poster');
            if (movieData.poster_path) {
                posterElement.src = `${CONFIG.IMAGE_BASE_URL}${movieData.poster_path}`;
                posterElement.alt = `${movieData.title} Poster`;
            } else {
                posterElement.src = CONFIG.DEFAULT_PLACEHOLDER;
                posterElement.alt = 'Sem imagem disponível';
            }
            
            // Preencher metadados
            const metaContainer = document.getElementById('detail-meta');
            metaContainer.innerHTML = '';
            
            if (movieData.release_date) {
                const yearSpan = document.createElement('span');
                yearSpan.textContent = movieData.release_date.substring(0, 4);
                metaContainer.appendChild(yearSpan);
            }
            
            if (movieData.runtime) {
                const runtimeSpan = document.createElement('span');
                runtimeSpan.textContent = `${movieData.runtime} min`;
                metaContainer.appendChild(runtimeSpan);
            }
            
            if (movieData.vote_average) {
                const ratingSpan = document.createElement('span');
                ratingSpan.className = 'movie-rating';
                ratingSpan.textContent = movieData.vote_average.toFixed(1);
                metaContainer.appendChild(ratingSpan);
            }
            
            // Preencher géneros
            const genresContainer = document.getElementById('detail-genres');
            genresContainer.innerHTML = '';
            
            if (movieData.genres && movieData.genres.length > 0) {
                movieData.genres.forEach(genre => {
                    const genreSpan = document.createElement('span');
                    genreSpan.className = 'genre-tag';
                    genreSpan.textContent = genre.name;
                    genresContainer.appendChild(genreSpan);
                });
            }
            
            // Carregar elenco
            const creditsData = await TMDbAPI.getMovieCredits(movieId);
            const castContainer = document.getElementById('detail-cast');
            castContainer.innerHTML = '';
            
            if (creditsData && creditsData.cast && creditsData.cast.length > 0) {
                // Limitar a 10 atores
                const cast = creditsData.cast.slice(0, 10);
                
                cast.forEach(actor => {
                    const actorElement = document.createElement('div');
                    actorElement.className = 'cast-item';
                    
                    const profileUrl = actor.profile_path 
                        ? `${CONFIG.IMAGE_BASE_URL}${actor.profile_path}`
                        : CONFIG.DEFAULT_PLACEHOLDER;
                    
                    actorElement.innerHTML = `
                        <img src="${profileUrl}" alt="${actor.name}" onerror="this.onerror=null;this.src='${CONFIG.DEFAULT_PLACEHOLDER}';">
                        <h4>${actor.name}</h4>
                        <p>${actor.character || 'Desconhecido'}</p>
                    `;
                    
                    castContainer.appendChild(actorElement);
                });
            } else {
                castContainer.innerHTML = '<p class="no-results-message">Informações do elenco não disponíveis.</p>';
            }
            
            // Carregar filmes similares
            const similarData = await TMDbAPI.getSimilarMovies(movieId);
            const similarContainer = document.getElementById('detail-similar');
            similarContainer.innerHTML = '';
            
            document.getElementById('similar-title').textContent = 'Filmes Semelhantes';
            
            if (similarData && similarData.results && similarData.results.length > 0) {
                // Limitar a 6 filmes similares
                const similarMovies = similarData.results.slice(0, 6);
                UI.renderMediaItems(similarMovies, 'detail-similar', 'movie');
            } else {
                similarContainer.innerHTML = '<p class="no-results-message">Não há filmes semelhantes disponíveis.</p>';
            }
        } catch (error) {
            console.error('Erro ao renderizar detalhes do filme:', error);
            UI.showError('Não foi possível carregar os detalhes do filme. Por favor, tente novamente mais tarde.');
        }
    }
    
    /**
     * Renderiza a página de detalhes de uma série
     * @param {number} tvId - ID da série
     */
    static async renderTVShowDetailsPage(tvId) {
        UI.showLoading();
        
        try {
            // Obter o template da página de detalhes
            const template = document.getElementById('movie-details-template');
            const main = document.getElementById('main-content');
            main.innerHTML = template.innerHTML;
            
            // Carregar detalhes da série
            const tvData = await TMDbAPI.getTVShowDetails(tvId);
            if (!tvData) {
                UI.showError('Série não encontrada.');
                return;
            }
            
            // Adicionar backdrop se disponível
            if (tvData.backdrop_path) {
                const backdropUrl = `${CONFIG.IMAGE_BASE_URL}${tvData.backdrop_path}`;
                const backdropDiv = document.createElement('div');
                backdropDiv.className = 'backdrop';
                backdropDiv.style.backgroundImage = `linear-gradient(to bottom, rgba(20, 20, 20, 0.5) 0%, rgba(20, 20, 20, 1) 100%), url('${backdropUrl}')`;
                
                // Inserir o backdrop antes do conteúdo principal
                const movieDetails = main.querySelector('.movie-details');
                main.insertBefore(backdropDiv, movieDetails);
                
                // Mover os detalhes da série para dentro do backdrop
                const detailsHeader = main.querySelector('.movie-details-header');
                const detailsContainer = document.createElement('div');
                detailsContainer.className = 'movie-details-container';
                detailsContainer.appendChild(detailsHeader);
                backdropDiv.appendChild(detailsContainer);
            }
            
            // Preencher detalhes da série
            document.getElementById('detail-title').textContent = tvData.name || 'Sem título';
            document.getElementById('detail-overview').textContent = tvData.overview || 'Sem sinopse disponível.';
            
            // Preencher poster
            const posterElement = document.getElementById('detail-poster');
            if (tvData.poster_path) {
                posterElement.src = `${CONFIG.IMAGE_BASE_URL}${tvData.poster_path}`;
                posterElement.alt = `${tvData.name} Poster`;
            } else {
                posterElement.src = CONFIG.DEFAULT_PLACEHOLDER;
                posterElement.alt = 'Sem imagem disponível';
            }
            
            // Preencher metadados
            const metaContainer = document.getElementById('detail-meta');
            metaContainer.innerHTML = '';
            
            if (tvData.first_air_date) {
                const yearSpan = document.createElement('span');
                yearSpan.textContent = tvData.first_air_date.substring(0, 4);
                metaContainer.appendChild(yearSpan);
            }
            
            if (tvData.number_of_seasons) {
                const seasonsSpan = document.createElement('span');
                seasonsSpan.textContent = `${tvData.number_of_seasons} Temporada${tvData.number_of_seasons > 1 ? 's' : ''}`;
                metaContainer.appendChild(seasonsSpan);
            }
            
            if (tvData.vote_average) {
                const ratingSpan = document.createElement('span');
                ratingSpan.className = 'movie-rating';
                ratingSpan.textContent = tvData.vote_average.toFixed(1);
                metaContainer.appendChild(ratingSpan);
            }
            
            // Preencher géneros
            const genresContainer = document.getElementById('detail-genres');
            genresContainer.innerHTML = '';
            
            if (tvData.genres && tvData.genres.length > 0) {
                tvData.genres.forEach(genre => {
                    const genreSpan = document.createElement('span');
                    genreSpan.className = 'genre-tag';
                    genreSpan.textContent = genre.name;
                    genresContainer.appendChild(genreSpan);
                });
            }
            
            // Carregar elenco
            const creditsData = await TMDbAPI.getTVShowCredits(tvId);
            const castContainer = document.getElementById('detail-cast');
            castContainer.innerHTML = '';
            
            if (creditsData && creditsData.cast && creditsData.cast.length > 0) {
                // Limitar a 10 atores
                const cast = creditsData.cast.slice(0, 10);
                
                cast.forEach(actor => {
                    const actorElement = document.createElement('div');
                    actorElement.className = 'cast-item';
                    
                    const profileUrl = actor.profile_path 
                        ? `${CONFIG.IMAGE_BASE_URL}${actor.profile_path}`
                        : CONFIG.DEFAULT_PLACEHOLDER;
                    
                    actorElement.innerHTML = `
                        <img src="${profileUrl}" alt="${actor.name}" onerror="this.onerror=null;this.src='${CONFIG.DEFAULT_PLACEHOLDER}';">
                        <h4>${actor.name}</h4>
                        <p>${actor.character || 'Desconhecido'}</p>
                    `;
                    
                    castContainer.appendChild(actorElement);
                });
            } else {
                castContainer.innerHTML = '<p class="no-results-message">Informações do elenco não disponíveis.</p>';
            }
            
            // Carregar séries similares
            const similarData = await TMDbAPI.getSimilarTVShows(tvId);
            const similarContainer = document.getElementById('detail-similar');
            similarContainer.innerHTML = '';
            
            document.getElementById('similar-title').textContent = 'Séries Semelhantes';
            
            if (similarData && similarData.results && similarData.results.length > 0) {
                // Limitar a 6 séries similares
                const similarShows = similarData.results.slice(0, 6);
                UI.renderMediaItems(similarShows, 'detail-similar', 'tv');
            } else {
                similarContainer.innerHTML = '<p class="no-results-message">Não há séries semelhantes disponíveis.</p>';
            }
        } catch (error) {
            console.error('Erro ao renderizar detalhes da série:', error);
            UI.showError('Não foi possível carregar os detalhes da série. Por favor, tente novamente mais tarde.');
        }
    }
    
    /**
     * Renderiza a página de resultados de pesquisa
     * @param {string} query - Termo de pesquisa
     */
    static async renderSearchResultsPage(query) {
        UI.showLoading();
        
        try {
            // Obter o template da página de resultados de pesquisa
            const template = document.getElementById('search-results-template');
            const main = document.getElementById('main-content');
            main.innerHTML = template.innerHTML;
            
            // Definir o termo de pesquisa
            document.getElementById('search-query').textContent = query;
            
            // Pesquisar filmes
            const moviesData = await TMDbAPI.searchMovies(query);
            const moviesContainer = document.getElementById('search-movies');
            const noMoviesMessage = document.getElementById('no-movies-message');
            
            if (moviesData && moviesData.results && moviesData.results.length > 0) {
                UI.renderMediaItems(moviesData.results, 'search-movies', 'movie');
                noMoviesMessage.style.display = 'none';
            } else {
                moviesContainer.innerHTML = '';
                noMoviesMessage.style.display = 'block';
            }
            
            // Pesquisar séries
            const tvData = await TMDbAPI.searchTVShows(query);
            const seriesContainer = document.getElementById('search-series');
            const noSeriesMessage = document.getElementById('no-series-message');
            
            if (tvData && tvData.results && tvData.results.length > 0) {
                UI.renderMediaItems(tvData.results, 'search-series', 'tv');
                noSeriesMessage.style.display = 'none';
            } else {
                seriesContainer.innerHTML = '';
                noSeriesMessage.style.display = 'block';
            }
        } catch (error) {
            console.error('Erro ao renderizar resultados de pesquisa:', error);
            UI.showError('Não foi possível carregar os resultados da pesquisa. Por favor, tente novamente mais tarde.');
        }
    }
}
