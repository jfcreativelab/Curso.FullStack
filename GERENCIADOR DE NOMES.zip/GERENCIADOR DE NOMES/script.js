document.addEventListener("DOMContentLoaded", () => {
  const nomeInput = document.getElementById("nomeInput");
  const adicionarBtn = document.getElementById("adicionarBtn");
  const listaNomesUl = document.getElementById("listaNomes");

  const filtroLetraInput = document.getElementById("filtroLetraInput");
  const filtrarBtn = document.getElementById("filtrarBtn");
  const listaNomesFiltradosUl = document.getElementById("listaNomesFiltrados");
  const nomesFiltradosArea = document.getElementById("nomesFiltradosArea");

  const buscarNomeInput = document.getElementById("buscarNomeInput");
  const buscarBtn = document.getElementById("buscarBtn");
  const resultadoBuscaP = document.getElementById("resultadoBusca");

  const transformarBtn = document.getElementById("transformarBtn");
  const listaNomesTransformadosUl = document.getElementById("listaNomesTransformados");
  const nomesTransformadosArea = document.getElementById("nomesTransformadosArea");

  const verificarBtn = document.getElementById("verificarBtn");
  const resultadoVerificacaoP = document.getElementById("resultadoVerificacao");

  let nomes = [];

  function limparResultadosSecundarios() {
      resultadoBuscaP.textContent = "";
      resultadoVerificacaoP.textContent = "";
      listaNomesFiltradosUl.innerHTML = "";
      nomesFiltradosArea.style.display = "none";
      listaNomesTransformadosUl.innerHTML = "";
      nomesTransformadosArea.style.display = "none";
  }

  function renderizarNomes() {
      listaNomesUl.innerHTML = ""; 
      if (nomes.length === 0) {
          const li = document.createElement("li");
          li.textContent = "A lista de nomes está vazia.";
          listaNomesUl.appendChild(li);
      } else {
          nomes.forEach(nome => {
              const li = document.createElement("li");
              li.textContent = nome;
              listaNomesUl.appendChild(li);
          });
      }
      // Não limpar resultados secundários aqui para que o utilizador possa ver o resultado da última ação
  }

  adicionarBtn.addEventListener("click", () => {
      limparResultadosSecundarios();
      const nome = nomeInput.value.trim();
      if (nome) {
          nomes.push(nome);
          nomeInput.value = ""; 
          renderizarNomes();
          alert(`"${nome}" foi adicionado à lista.`);
      } else {
          alert("Por favor, digite um nome válido.");
      }
  });

  filtrarBtn.addEventListener("click", () => {
      limparResultadosSecundarios();
      const letra = filtroLetraInput.value.trim();
      if (!letra || letra.length !== 1 || !/^[a-zA-Z]$/.test(letra)) {
          alert("Por favor, digite uma única letra para filtrar.");
          filtroLetraInput.value = "";
          return;
      }

      const nomesFiltrados = nomes.filter(nome => nome.toLowerCase().startsWith(letra.toLowerCase()));
      
      listaNomesFiltradosUl.innerHTML = ""; 
      nomesFiltradosArea.style.display = "block";
      if (nomesFiltrados.length > 0) {
          nomesFiltrados.forEach(nome => {
              const li = document.createElement("li");
              li.textContent = nome;
              listaNomesFiltradosUl.appendChild(li);
          });
      } else {
          const li = document.createElement("li");
          li.textContent = `Nenhum nome encontrado que comece com a letra "${letra}".`;
          listaNomesFiltradosUl.appendChild(li);
      }
      filtroLetraInput.value = ""; 
  });

  buscarBtn.addEventListener("click", () => {
      limparResultadosSecundarios();
      const nomeParaBuscar = buscarNomeInput.value.trim();
      if (!nomeParaBuscar) {
          alert("Por favor, digite um nome para buscar.");
          return;
      }

      const nomeEncontrado = nomes.find(nome => nome.toLowerCase() === nomeParaBuscar.toLowerCase());

      if (nomeEncontrado) {
          resultadoBuscaP.textContent = `Nome encontrado: "${nomeEncontrado}"`;
      } else {
          resultadoBuscaP.textContent = `Nome "${nomeParaBuscar}" não encontrado na lista.`;
      }
      buscarNomeInput.value = "";
  });

  transformarBtn.addEventListener("click", () => {
      limparResultadosSecundarios();
      if (nomes.length === 0) {
          alert("A lista de nomes está vazia. Adicione nomes primeiro.");
          return;
      }

      const nomesMaiusculos = nomes.map(nome => nome.toUpperCase());
      
      listaNomesTransformadosUl.innerHTML = "";
      nomesTransformadosArea.style.display = "block";
      nomesMaiusculos.forEach(nome => {
          const li = document.createElement("li");
          li.textContent = nome;
          listaNomesTransformadosUl.appendChild(li);
      });
  });

  verificarBtn.addEventListener("click", () => {
      limparResultadosSecundarios();
      if (nomes.length === 0) {
          alert("A lista de nomes está vazia. Adicione nomes primeiro para verificar.");
          resultadoVerificacaoP.textContent = "A lista está vazia.";
          return;
      }
      const todosTemMaisDeTresCaracteres = nomes.every(nome => nome.length > 3);
      resultadoVerificacaoP.textContent = `Todos os nomes na lista têm mais de 3 caracteres? ${todosTemMaisDeTresCaracteres}`;
  });

  // Inicializa a exibição da lista (vazia no início)
  renderizarNomes();

});

