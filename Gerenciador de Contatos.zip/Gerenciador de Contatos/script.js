
document.addEventListener('DOMContentLoaded', function() {

    const contactForm = document.getElementById('contactForm');
    const contactsList = document.getElementById('contactsList');
    const searchInput = document.getElementById('searchInput');
    const cancelBtn = document.getElementById('cancelBtn');
    const themeToggle = document.getElementById('themeToggle');
    const categoryTabs = document.getElementById('categoryTabs');
    const sortSelect = document.getElementById('sortSelect');
    const exportBtn = document.getElementById('exportBtn');
    const exportModal = document.getElementById('exportModal');
    const closeModal = document.querySelector('.close-modal');
    const exportJSON = document.getElementById('exportJSON');
    const exportCSV = document.getElementById('exportCSV');
    const exportVCF = document.getElementById('exportVCF');
    const notification = document.getElementById('notification');
    const totalContactsEl = document.getElementById('totalContacts');
    const totalCategoriesEl = document.getElementById('totalCategories');

    
    let contacts = JSON.parse(localStorage.getItem('contacts')) || [];
    let isEditing = false;
    let currentContactId = null;
    let currentCategory = 'Todas';
    
    initTheme();
    renderContacts();
    updateStats();

    contactForm.addEventListener('submit', handleSubmit);
    searchInput.addEventListener('input', filterContacts);
    cancelBtn.addEventListener('click', cancelEdit);
    themeToggle.addEventListener('click', toggleTheme);
    sortSelect.addEventListener('change', sortContacts);
    exportBtn.addEventListener('click', () => exportModal.style.display = 'block');
    closeModal.addEventListener('click', () => exportModal.style.display = 'none');
    exportJSON.addEventListener('click', exportToJSON);
    exportCSV.addEventListener('click', exportToCSV);
    exportVCF.addEventListener('click', exportToVCF);

    window.addEventListener('click', (e) => {
        if (e.target === exportModal) {
            exportModal.style.display = 'none';
        }
    });

    function handleSubmit(e) {
        e.preventDefault();
        
        const name = document.getElementById('name').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const email = document.getElementById('email').value.trim();
        const address = document.getElementById('address').value.trim();
        const category = document.getElementById('category').value;
        
        if (!name || !phone) {
            showNotification('Preencha pelo menos nome e telefone', 'error');
            return;
        }

        if (isEditing) {

            updateContact(currentContactId, name, phone, email, address, category);
            showNotification('Contato atualizado com sucesso!', 'success');
        } else {
            
            addContact(name, phone, email, address, category);
            showNotification('Contato adicionado com sucesso!', 'success');
        }
        
       
        contactForm.reset();
        isEditing = false;
        currentContactId = null;
        document.getElementById('contactId').value = '';
        cancelBtn.style.display = 'none';
    }
    

    function addContact(name, phone, email, address, category) {
        const newContact = {
            id: Date.now().toString(),
            name,
            phone,
            email,
            address,
            category,
            createdAt: new Date().toISOString()
        };
        
        contacts.push(newContact);
        saveContacts();
        renderContacts();
        updateStats();
    }
    
    
    function updateContact(id, name, phone, email, address, category) {
        contacts = contacts.map(contact => 
            contact.id === id ? { 
                ...contact, 
                name, 
                phone, 
                email, 
                address, 
                category,
                updatedAt: new Date().toISOString()
            } : contact
        );
        
        saveContacts();
        renderContacts();
        updateStats();
    }
    
    
    function deleteContact(id) {
        if (confirm('Tem certeza que deseja excluir este contato?')) {
            contacts = contacts.filter(contact => contact.id !== id);
            saveContacts();
            renderContacts();
            updateStats();
            
           
            if (currentContactId === id) {
                contactForm.reset();
                isEditing = false;
                currentContactId = null;
                document.getElementById('contactId').value = '';
                cancelBtn.style.display = 'none';
            }
            
            showNotification('Contato removido com sucesso!', 'success');
        }
    }
    
    
    function editContact(id) {
        const contact = contacts.find(contact => contact.id === id);
        if (contact) {
            document.getElementById('contactId').value = contact.id;
            document.getElementById('name').value = contact.name;
            document.getElementById('phone').value = contact.phone;
            document.getElementById('email').value = contact.email || '';
            document.getElementById('address').value = contact.address || '';
            document.getElementById('category').value = contact.category || 'Geral';
            
            isEditing = true;
            currentContactId = id;
            cancelBtn.style.display = 'inline-block';
            
       
            document.querySelector('.form-container').scrollIntoView({ behavior: 'smooth' });
        }
    }
    

    function cancelEdit() {
        contactForm.reset();
        isEditing = false;
        currentContactId = null;
        document.getElementById('contactId').value = '';
        cancelBtn.style.display = 'none';
    }
    

    function filterContacts() {
        const searchTerm = searchInput.value.toLowerCase();
        const filteredContacts = contacts.filter(contact => 
            contact.name.toLowerCase().includes(searchTerm) ||
            contact.phone.toLowerCase().includes(searchTerm) ||
            (contact.email && contact.email.toLowerCase().includes(searchTerm)) ||
            (contact.address && contact.address.toLowerCase().includes(searchTerm))
        );
        
        renderContacts(filteredContacts);
    }
    
    function sortContacts() {
        const sortValue = sortSelect.value;
        let sortedContacts = [...contacts];
        
        switch(sortValue) {
            case 'name-asc':
                sortedContacts.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'name-desc':
                sortedContacts.sort((a, b) => b.name.localeCompare(a.name));
                break;
            case 'date-asc':
                sortedContacts.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
                break;
            case 'date-desc':
                sortedContacts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
                break;
        }
        
        renderContacts(sortedContacts);
    }

    function filterByCategory(category) {
        currentCategory = category;
        if (category === 'Todas') {
            renderContacts();
        } else {
            const filteredContacts = contacts.filter(contact => contact.category === category);
            renderContacts(filteredContacts);
        }
        
        document.querySelectorAll('.category-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.category === category);
        });
    }
    
    function renderContacts(contactsToRender = contacts) {

        updateCategoryTabs();
        
        if (contactsToRender.length === 0) {
            contactsList.innerHTML = '<p class="no-contacts">Nenhum contato encontrado.</p>';
            return;
        }
        
        contactsList.innerHTML = contactsToRender.map(contact => `
            <div class="contact-card" data-category="${contact.category}">
                <div class="contact-info">
                    <h3>${contact.name} <span class="category-badge">${contact.category}</span></h3>
                    <p><i class="fas fa-phone"></i> ${formatPhone(contact.phone)}</p>
                    ${contact.email ? `<p><i class="fas fa-envelope"></i> ${contact.email}</p>` : ''}
                    ${contact.address ? `<p><i class="fas fa-map-marker-alt"></i> ${contact.address}</p>` : ''}
                    <p class="date-info"><i class="far fa-clock"></i> Criado em: ${formatDate(contact.createdAt)}</p>
                    ${contact.updatedAt ? `<p class="date-info"><i class="fas fa-sync-alt"></i> Atualizado em: ${formatDate(contact.updatedAt)}</p>` : ''}
                </div>
                <div class="contact-actions">
                    <button class="btn" onclick="editContact('${contact.id}')">
                        <i class="fas fa-edit"></i> Editar
                    </button>
                    <button class="btn btn-danger" onclick="deleteContact('${contact.id}')">
                        <i class="fas fa-trash-alt"></i> Excluir
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    function updateCategoryTabs() {
        const categories = ['Todas', ...new Set(contacts.map(c => c.category))];
        
        categoryTabs.innerHTML = categories.map(cat => `
            <div class="category-tab ${currentCategory === cat ? 'active' : ''}" 
                 data-category="${cat}" 
                 onclick="filterByCategory('${cat}')">
                ${cat}
            </div>
        `).join('');
    }
    
    function saveContacts() {
        localStorage.setItem('contacts', JSON.stringify(contacts));
    }
    
    function formatPhone(phone) {

        return phone.replace(/(\d{2})(\d{4,5})(\d{4})/, '($1) $2-$3');
    }
    
    function formatDate(dateString) {
        const options = { 
            day: '2-digit', 
            month: '2-digit', 
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        };
        return new Date(dateString).toLocaleDateString('pt-BR', options);
    }
    
    function exportToJSON() {
        const dataStr = JSON.stringify(contacts, null, 2);
        downloadFile(dataStr, 'contatos.json', 'application/json');
        exportModal.style.display = 'none';
        showNotification('Contatos exportados como JSON!', 'success');
    }
    
    function exportToCSV() {
        const headers = ['Nome', 'Telefone', 'Email', 'Endereço', 'Categoria'];
        const rows = contacts.map(c => [
            `"${c.name}"`,
            `"${c.phone}"`,
            `"${c.email || ''}"`,
            `"${c.address || ''}"`,
            `"${c.category || ''}"`
        ]);
        
        const csvContent = [
            headers.join(','),
            ...rows.map(row => row.join(','))
        ].join('\n');
        
        downloadFile(csvContent, 'contatos.csv', 'text/csv');
        exportModal.style.display = 'none';
        showNotification('Contatos exportados como CSV!', 'success');
    }
    
    function exportToVCF() {
        let vcfContent = '';
        
        contacts.forEach(contact => {
            vcfContent += `BEGIN:VCARD\n`;
            vcfContent += `VERSION:3.0\n`;
            vcfContent += `FN:${contact.name}\n`;
            vcfContent += `TEL;TYPE=CELL:${contact.phone}\n`;
            if (contact.email) vcfContent += `EMAIL:${contact.email}\n`;
            if (contact.address) vcfContent += `ADR:;;${contact.address}\n`;
            vcfContent += `END:VCARD\n\n`;
        });
        
        downloadFile(vcfContent, 'contatos.vcf', 'text/vcard');
        exportModal.style.display = 'none';
        showNotification('Contatos exportados como vCard!', 'success');
    }
    
    // Função auxiliar para download
    function downloadFile(content, fileName, contentType) {
        const blob = new Blob([content], { type: contentType });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        
        setTimeout(() => {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }, 100);
    }
    
    function showNotification(message, type) {
        notification.textContent = message;
        notification.className = `notification ${type} show`;
        notification.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}`;
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
    
    function updateStats() {
        totalContactsEl.textContent = contacts.length;
        
        const uniqueCategories = new Set(contacts.map(c => c.category));
        totalCategoriesEl.textContent = uniqueCategories.size;
    }

    function initTheme() {
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        updateThemeIcon(savedTheme);
    }
    
    function toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateThemeIcon(newTheme);
    }
    
    function updateThemeIcon(theme) {
        const icon = theme === 'dark' ? 'sun' : 'moon';
        themeToggle.innerHTML = `<i class="fas fa-${icon}"></i>`;
    }
    
    window.editContact = editContact;
    window.deleteContact = deleteContact;
    window.filterByCategory = filterByCategory;
});

