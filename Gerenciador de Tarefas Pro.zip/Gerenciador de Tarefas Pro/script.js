
let tasks = [];
let productivityLog = []; // [{date, completed}]
const LSKEY = 'todoAppProV1-tasks';
const LOGKEY = 'todoAppProV1-log';

function saveTasks() { localStorage.setItem(LSKEY, JSON.stringify(tasks)); }
function loadTasks() {
  const data = localStorage.getItem(LSKEY);
  if (data) tasks = JSON.parse(data);
  const log = localStorage.getItem(LOGKEY);
  if (log) productivityLog = JSON.parse(log);
}

function saveProductivityLog() { localStorage.setItem(LOGKEY, JSON.stringify(productivityLog)); }

function getToday() {
  const dt = new Date();
  return dt.toISOString().slice(0,10);
}

const tasksList = document.getElementById('tasksList');
const statTotal = document.getElementById('statTotal');
const statDone = document.getElementById('statDone');
const statPending = document.getElementById('statPending');
const productivityChart = document.getElementById('productivityChart').getContext('2d');
let productivityChartObj;

function renderTasks() {
  const filterCat = document.getElementById('filterCategory').value;
  const filterPriority = document.getElementById('filterPriority').value;
  const filterStatus = document.getElementById('filterStatus').value;
  const searchVal = document.getElementById('searchTask').value.toLowerCase();

  let filtered = tasks.slice();

  if (filterCat) filtered = filtered.filter(t => t.category === filterCat);
  if (filterPriority) filtered = filtered.filter(t => t.priority === filterPriority);
  if (filterStatus === 'pendente') filtered = filtered.filter(t => !t.done && !isTaskLate(t));
  else if (filterStatus === 'concluida') filtered = filtered.filter(t => t.done);
  else if (filterStatus === 'atrasada') filtered = filtered.filter(t => !t.done && isTaskLate(t));
  if (searchVal)
    filtered = filtered.filter(t => t.text.toLowerCase().includes(searchVal) || (t.note && t.note.toLowerCase().includes(searchVal)) );

  filtered.sort((a,b) => {
    const p = {"Alta":2,"Média":1,"Baixa":0};
    if (p[b.priority] !== p[a.priority])
      return p[b.priority] - p[a.priority];
    if ((a.dueDate||'') !== (b.dueDate||''))
      return (a.dueDate||'9999-99-99').localeCompare(b.dueDate||'9999-99-99');
    return a.idx - b.idx;
  });

  tasksList.innerHTML = '';
  if(filtered.length === 0) {
    tasksList.innerHTML = `<div class="py-8 text-center text-gray-500 dark:text-gray-400"><i class="far fa-smile-beam text-2xl"></i> Nenhuma tarefa encontrada.</div>`;
    return;
  }

  filtered.forEach(task => {
    let priorityColor = 'gray-400', priorityIcon = 'fa-arrow-down';
    if(task.priority === 'Alta') priorityColor = 'red-500', priorityIcon = 'fa-arrow-up';
    else if(task.priority === 'Média') priorityColor = 'yellow-400', priorityIcon = 'fa-arrow-right';

    let categoryColor = {
      'Trabalho':'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      'Estudos':'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      'Pessoal':'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300',
      'Saúde':'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
      'Casa':'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-300',
      'Outro':'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
    }[task.category] || 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-200';

    const isLate = isTaskLate(task);
    const taskCard = document.createElement('div');
    taskCard.className =
      "transition transform duration-200 task-card bg-white dark:bg-gray-800 rounded-lg shadow flex items-start px-4 py-3 mb-3 group select-none relative draggable cursor-move"
      + (task.done ? " opacity-60 line-through" : "")
      + (isLate && !task.done ? " ring-2 ring-red-200 dark:ring-red-700" : "");

    taskCard.setAttribute('draggable', 'true');
    taskCard.dataset.idx = task.idx;

    taskCard.innerHTML = `
      <input type="checkbox" aria-label="Concluir tarefa" ${task.done ? 'checked' : ''} class="mt-2 mr-4 accent-indigo-600 h-5 w-5" onclick="toggleTaskDone(${task.idx})">
      <div class="flex-1">
        <span class="flex items-center">
          <span class="font-semibold mr-2">${task.text}</span>
          <span class="ml-auto px-2 py-1 ${categoryColor} text-xs font-semibold rounded mr-2">${task.category||'Sem categoria'}</span>
          <i class="fas ${priorityIcon} text-${priorityColor} ml-1 tooltip"><span class="tooltip-text capitalize">Prioridade: ${task.priority}</span></i>
        </span>
        <div class="text-xs flex items-center flex-wrap mt-1 gap-x-3 gap-y-1">
          <span class="mr-2 flex items-center">
            <i class="far fa-calendar-alt mr-1"></i>${task.dueDate ? `${formatDate(task.dueDate)}${ isLate&&!task.done ? ' <span class=\'text-red-500 font-bold\'>(Atrasada)</span>':''}` : 'Sem vencimento'}
          </span>
          ${task.note ? `<span class="text-gray-400 italic">"${task.note.replace(/"/g,'&quot;')}"</span>` : ''}
        </div>
      </div>
      <div class="flex flex-row gap-2 ml-2">
        <button title="Editar" class="text-indigo-500 hover:bg-indigo-100 dark:hover:bg-indigo-700 rounded p-2 focus:outline-none" onclick="openEditModal(${task.idx})"><i class="fas fa-pen fa-fw"></i></button>
        <button title="Excluir" class="text-red-500 hover:bg-red-100 dark:hover:bg-red-700 rounded p-2 focus:outline-none" onclick="deleteTask(${task.idx})"><i class="fas fa-trash fa-fw"></i></button>
      </div>
    `;
    dragDropSetup(taskCard);

    tasksList.appendChild(taskCard);
  });
}

function formatDate(str) {
  if (!str) return '';
  const [y,m,d] = str.split("-");
  return `${d}/${m}/${y}`;
}
function isTaskLate(t){
  if(!t.dueDate||t.done) return false;
  return new Date(t.dueDate) < new Date(getToday());
}

function addTask(text, category, priority, dueDate) {
  const idx = tasks.length>0 ? Math.max(...tasks.map(t=>t.idx))+1 : 1;
  tasks.push({
    idx,
    text,
    category: category || '',
    priority: priority || 'Baixa',
    dueDate: dueDate || '',
    done: false,
    note: '',
    created: new Date().toISOString().slice(0,10)
  });
  saveTasks();
  renderAll();
  toast('Tarefa adicionada!', "success");
}
function updateTask(idx, data) {
  const t = tasks.find(t=>t.idx==idx);
  if (!t) return;
  Object.assign(t, data);
  saveTasks();
  renderAll();
  toast('Tarefa atualizada!', "success");
}
function toggleTaskDone(idx) {
  const t = tasks.find(t=>t.idx==idx);
  if(!t) return;
  t.done = !t.done;
  saveTasks();
  productivityDailyUpdate();
  renderAll();
  toast(t.done ? 'Tarefa concluída!' : 'Tarefa marcada como pendente.', "info");
}
function deleteTask(idx) {
  if (!confirm("Tem certeza de que deseja excluir esta tarefa?")) return;
  const i = tasks.findIndex(t=>t.idx==idx);
  if (i>=0) tasks.splice(i,1);
  saveTasks();
  renderAll();
  toast('Tarefa removida.', "danger");
}

['filterCategory','filterPriority','filterStatus','searchTask'].forEach(id=>{
  document.getElementById(id).addEventListener('input', renderTasks);
});

document.getElementById('taskForm').onsubmit = function(e){
  e.preventDefault();
  const text = document.getElementById('taskInput').value.trim();
  if(!text) return;
  addTask(
    text,
    document.getElementById('categoryInput').value,
    document.getElementById('priorityInput').value,
    document.getElementById('dueDateInput').value
  );
  document.getElementById('taskInput').value = '';
  document.getElementById('categoryInput').value = '';
  document.getElementById('priorityInput').value = 'Baixa';
  document.getElementById('dueDateInput').value = '';
};

function productivityDailyUpdate(){
  const today = getToday();
  const doneToday = tasks.filter(t=>t.done && t.created<=today && (!t.dueDate || t.dueDate<=today)).length;
  productivityLog = productivityLog.filter(l=>l.date!=today);
  productivityLog.push({ date: today, completed: doneToday });
  productivityLog = productivityLog.filter(l=> (new Date(today)-new Date(l.date))<=7*24*60*60*1000 );
  saveProductivityLog();
}
function renderStats() {
  statTotal.textContent = tasks.length;
  const done = tasks.filter(t=>t.done).length;
  statDone.textContent = done;
  statPending.textContent = tasks.filter(t=>!t.done).length;
  const days = [];
  const today = new Date(getToday());
  for(let i=6; i>=0; i--){
    const d = new Date( today.getTime() - i*24*60*60*1000 );
    days.push( d.toISOString().slice(0,10) );
  }
  const data = days.map(d => {
    const found = productivityLog.find(l=>l.date==d);
    return found ? found.completed : 0;
  });
  if (productivityChartObj) productivityChartObj.destroy();
  productivityChartObj = new Chart(productivityChart, {
    type: 'bar',
    data: {
      labels: days.map(d=>d.slice(5).split('-').reverse().join('/')),
      datasets: [{
        label: 'Concluídas',
        data,
        backgroundColor: ['#a5b4fc','#34d399','#facc15','#c4b5fd','#f472b6','#60a5fa','#fde68a'],
        borderRadius: 8,
      }]
    },
    options: {
      plugins: { legend: { display: false }, tooltip: { enabled: true } },
      scales: { y: { display:false, beginAtZero:true, max: Math.max(...data,2) } },
      animation: { duration: 700 }
    }
  });
}

const darkToggle = document.getElementById('darkToggle');
darkToggle.onchange = function() {
  if(this.checked) {
    document.body.classList.add('dark-mode');
    localStorage.setItem('todoAppProV1-dark','Y');
  } else {
    document.body.classList.remove('dark-mode');
    localStorage.setItem('todoAppProV1-dark','N');
  }
};
function setupDarkMode() {
  const enabled = localStorage.getItem('todoAppProV1-dark') === 'Y';
  darkToggle.checked = enabled;
  if(enabled) document.body.classList.add('dark-mode');
}

function dragDropSetup(el) {
  el.addEventListener('dragstart', function(e){
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('idx',el.dataset.idx);
    el.classList.add('dragging');
  });
  el.addEventListener('dragend', function(){
    el.classList.remove('dragging');
  });
  el.addEventListener('dragover', e=>{
    e.preventDefault();
    el.classList.add('ring-4','ring-indigo-200');
  });
  el.addEventListener('dragleave', ()=>{
    el.classList.remove('ring-4','ring-indigo-200');
  });
  el.addEventListener('drop', function(e){
    e.preventDefault();
    el.classList.remove('ring-4','ring-indigo-200');
    const fromIdx = +e.dataTransfer.getData('idx');
    const toIdx = +el.dataset.idx;
    // Reordena array de tasks
    const idxA = tasks.findIndex(t=>t.idx===fromIdx);
    const idxB = tasks.findIndex(t=>t.idx===toIdx);
    if (idxA<0 || idxB<0 || idxA===idxB) return;
    // Move item
    const [item] = tasks.splice(idxA,1);
    tasks.splice(idxB,0,item);
    saveTasks();
    renderAll();
  });
}
function openEditModal(idx){
  const t = tasks.find(t=>t.idx==idx); if(!t) return;
  document.getElementById('editTaskInput').value = t.text;
  document.getElementById('editCategoryInput').value = t.category || '';
  document.getElementById('editPriorityInput').value = t.priority || 'Baixa';
  document.getElementById('editDueDateInput').value = t.dueDate || '';
  document.getElementById('editNoteInput').value = t.note || '';
  document.getElementById('editModal').classList.remove('hidden');
  document.getElementById('editTaskForm').onsubmit = function(e){
    e.preventDefault();
    updateTask(idx, {
      text: document.getElementById('editTaskInput').value,
      category: document.getElementById('editCategoryInput').value,
      priority: document.getElementById('editPriorityInput').value,
      dueDate: document.getElementById('editDueDateInput').value,
      note: document.getElementById('editNoteInput').value
    });
    closeEditModal();
  };
}
function closeEditModal(){
  document.getElementById('editModal').classList.add('hidden');
}

function toast(msg, type="info"){
  const colors = {
    info: "bg-indigo-500",
    success: "bg-green-600",
    danger: "bg-red-500"
  };
  const el = document.createElement('div');
  el.className = `${colors[type]||colors.info} text-white rounded-lg px-5 py-3 font-semibold shadow-lg mb-2 animate-bounceInDown`;
  el.textContent = msg;
  document.getElementById('toastArea').appendChild(el);
  setTimeout(()=>{ el.classList.add('animate-fadeOut'); },1400);
  setTimeout(()=>{ el.remove(); },1900);
}

function renderAll(){
  renderTasks();
  renderStats();
}

setupDarkMode();
loadTasks();
renderAll();
productivityDailyUpdate();
