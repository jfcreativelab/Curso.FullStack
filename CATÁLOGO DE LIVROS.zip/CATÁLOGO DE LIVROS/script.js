
let books = JSON.parse(localStorage.getItem('books')) || [];

function saveBooks() {
  localStorage.setItem('books', JSON.stringify(books));
}

function renderBooks(list = books) {
  const container = document.getElementById('books-container');
  container.innerHTML = '';

  if (list.length === 0) {
    container.innerHTML = '<p style="text-align: center;">Nenhum livro cadastrado.</p>';
    return;
  }

  list.forEach((book, index) => {
    const card = document.createElement('div');
    card.className = 'book-card';

    const image = document.createElement('img');
    image.className = 'book-image';
    image.src = book.image || 'https://via.placeholder.com/80x110?text=Sem+Capa';
    image.alt = `${book.title} - capa`;

    const info = document.createElement('div');
    info.className = 'book-info';
    info.innerHTML = `
      <p><strong>${book.title}</strong></p>
      <p>Autor: ${book.author}</p>
      <p>Gênero: ${book.genre}</p>
      <p>Ano: ${book.year}</p>
      <p>Avaliação: ${book.rating}/5</p>
    `;

    const controls = document.createElement('div');
    controls.className = 'control-buttons';

    const inputEval = document.createElement('input');
    inputEval.type = 'number';
    inputEval.min = '0';
    inputEval.max = '5';
    inputEval.step = '0.1';
    inputEval.className = 'input-evaluate';
    inputEval.placeholder = 'Nova nota';
    const btnEval = document.createElement('button');
    btnEval.className = 'btn-evaluate';
    btnEval.textContent = 'Atualizar Avaliação';
    btnEval.addEventListener('click', () => {
      const newRating = parseFloat(inputEval.value);
      if (!isNaN(newRating) && newRating >= 0 && newRating <= 5) {
        books[index].rating = newRating;
        saveBooks();
        renderBooks();
      } else {
        alert('Digite uma nota válida entre 0 e 5.');
      }
    });

    const btnRemove = document.createElement('button');
    btnRemove.className = 'btn-remove';
    btnRemove.textContent = 'Remover';
    btnRemove.addEventListener('click', () => {
      if(confirm(`Remover o livro "${book.title}"?`)){
        books.splice(index, 1);
        saveBooks();
        renderBooks();
      }
    });

    controls.appendChild(inputEval);
    controls.appendChild(btnEval);
    controls.appendChild(btnRemove);
    card.appendChild(image);
    card.appendChild(info);
    card.appendChild(controls);

    container.appendChild(card);
  });
}
function addBook(e) {
  e.preventDefault();
  
  const title = document.getElementById('title').value.trim();
  const author = document.getElementById('author').value.trim();
  const genre = document.getElementById('genre').value.trim();
  const year = parseInt(document.getElementById('year').value);
  const rating = parseFloat(document.getElementById('rating').value);
  const image = document.getElementById('image').value.trim();

  if (!title || !author || !genre || isNaN(year) || isNaN(rating) || rating < 0 || rating > 5) {
    alert('Preencha todos os campos corretamente!');
    return;
  }

  const newBook = { title, author, genre, year, rating, image };
  books.push(newBook);
  saveBooks();
  renderBooks();

  document.getElementById('book-form').reset();
}
function searchBooks() {
  const term = document.getElementById('search-input').value.toLowerCase();
  const filtered = books.filter(book => 
    book.title.toLowerCase().includes(term) ||
    book.author.toLowerCase().includes(term) ||
    book.genre.toLowerCase().includes(term)
  );
  renderBooks(filtered);
}

function sortBooks() {
  const criterion = document.getElementById('sort-select').value;
  if (criterion) {
    books.sort((a, b) => {
      if (criterion === 'rating') {
        return b.rating - a.rating;
      } else {
        return a[criterion].toLowerCase().localeCompare(b[criterion].toLowerCase());
      }
    });
    renderBooks();
  }
}

document.getElementById('book-form').addEventListener('submit', addBook);
document.getElementById('search-input').addEventListener('input', searchBooks);
document.getElementById('sort-select').addEventListener('change', sortBooks);

document.addEventListener('DOMContentLoaded', renderBooks);

class Livro {
  constructor(titulo, autor, ano) {
    this.titulo = titulo;
    this.autor = autor;
    this.ano = ano;
  }

  exibirInfo() {
    return `📖 "${this.titulo}" por ${this.autor}, publicado em ${this.ano}`;
  }
}

function usarClasseLivro() {
  const novo = new Livro("Dom Casmurro", "Machado de Assis", 1899);
  books.push(novo);
  saveBooks();
  renderBooks();
  alert("✅ Livro 'Dom Casmurro' adicionado via Classe Livro!");
}

function buscarLivroPorTitulo() {
  const titulo = prompt("Digite o título do livro a buscar:");
  if (!titulo) return;

  const encontrado = books.find(livro => livro.titulo.toLowerCase() === titulo.toLowerCase());

  if (encontrado) {
    alert("🔍 Livro encontrado:\n" + (encontrado.exibirInfo ? encontrado.exibirInfo() : `"${encontrado.titulo}" de ${encontrado.autor}, ${encontrado.ano}`));
  } else {
    alert("❌ Livro não encontrado.");
  }
}

function listarTodosLivros() {
  if (books.length === 0) return alert("📂 Biblioteca vazia.");

  let lista = "📚 Livros na Biblioteca:\n\n";
  for (const livro of books) {
    if (livro.titulo && livro.autor && livro.ano)
      lista += `- ${livro.titulo} (${livro.ano})\n`;
  }
  alert(lista);
}

function mostrarMediaIdade() {
  if (books.length === 0) return alert("⚠️ Nenhum livro para calcular.");

  const anoAtual = new Date().getFullYear();
  const soma = books.reduce((total, livro) => total + (anoAtual - livro.ano), 0);
  const media = soma / books.length;

  alert("📊 Média de idade dos livros: " + media.toFixed(2) + " anos.");
}
