document.addEventListener("DOMContentLoaded", () => {
    lucide.createIcons();
  
    const themeToggle = document.getElementById("toggle-theme");
    const addBtn = document.getElementById("addNote");
    const noteInput = document.getElementById("noteInput");
    const noteList = document.getElementById("noteList");
  
    themeToggle.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode");
      lucide.createIcons();
    });
  
    addBtn.addEventListener("click", () => {
      const value = noteInput.value.trim();
      if (!value) return;
  
      const note = document.createElement("li");
      note.className = "note";
  
      const input = document.createElement("input");
      input.type = "text";
      input.value = value;
      input.disabled = true;
  
      const actions = document.createElement("div");
      actions.className = "actions";
  
      const editBtn = document.createElement("button");
      editBtn.className = "edit";
      editBtn.innerHTML = '<i data-lucide="pencil"></i>';
      editBtn.onclick = () => {
        input.disabled = !input.disabled;
        if (!input.disabled) input.focus();
      };
  
      const deleteBtn = document.createElement("button");
      deleteBtn.className = "delete";
      deleteBtn.innerHTML = '<i data-lucide="trash-2"></i>';
      deleteBtn.onclick = () => {
        note.remove();
      };
  
      actions.append(editBtn, deleteBtn);
      note.append(input, actions);
      noteList.appendChild(note);
      lucide.createIcons();
  
      noteInput.value = "";
    });
  });
  