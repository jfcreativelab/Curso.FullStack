function iniciarColeta() {
    const nomes = [];
    let nome;
  
    while (true) {
      nome = prompt("Digite um nome (ou digite 'sair' para encerrar):");
  
      if (nome === null || nome.toLowerCase() === "sair") break;
  
      if (nome.trim() !== "") {
        nomes.push(nome.trim());
      }
    }
  
    const lista = document.getElementById("listaNomes");
    const mensagens = document.getElementById("mensagensBoasVindas");
  
    lista.innerHTML = "";
    mensagens.innerHTML = "";
  
    nomes.forEach((nome, index) => {
      const item = document.createElement("li");
      item.textContent = `${index + 1}: ${nome}`;
      lista.appendChild(item);
  
      const mensagem = document.createElement("li");
      mensagem.textContent = `Bem-vindo(a), ${nome.toUpperCase()}!`;
      mensagens.appendChild(mensagem);
    });
  }
  