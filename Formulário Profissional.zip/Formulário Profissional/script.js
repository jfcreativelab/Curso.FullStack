const form = document.getElementById("formCadastro");
const lista = document.getElementById("listaUsuarios");
const btnLimpar = document.getElementById("limparLista");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const nome = document.getElementById("nome").value.trim();
  const senha = document.getElementById("senha").value.trim();
  const telefone = document.getElementById("telefone").value.trim();
  const dataNascimento = document.getElementById("dataNascimento").value.trim();
  const email = document.getElementById("email").value.trim();

  if (!nome || !senha || !telefone || !dataNascimento || !email) {
    console.error("Todos os campos são obrigatórios.");
    alert("Preencha todos os campos corretamente.");
    return;
  }

  const usuarioDiv = document.createElement("div");
  usuarioDiv.innerHTML = `
    <strong>👤 Nome:</strong> ${nome}<br>
    <strong>📞 Telefone:</strong> ${telefone}<br>
    <strong>🎂 Nascimento:</strong> ${dataNascimento}<br>
    <strong>✉️ E-mail:</strong> ${email}
  `;

  lista.appendChild(usuarioDiv);
  form.reset();
});

btnLimpar.addEventListener("click", () => {
  lista.innerHTML = "";
});
