function verificar() {
    let idade = parseInt(document.getElementById("idade").value);
    let status = document.getElementById("status").value.toLowerCase();
    let mensagem = "";
  
    // Ternário
    let classificacaoIdade = (idade >= 18) ? "maior de idade" : "menor de idade";
    mensagem += `Você é <strong>${classificacaoIdade}</strong>.<br>`;
  
    // Switch
    switch (status) {
      case "registrado":
        mensagem += "Bem-vindo ao sistema!<br>";
        break;
      case "não registrado":
        mensagem += "Por favor, complete seu registro para continuar.<br>";
        break;
      default:
        mensagem += "Status desconhecido.<br>";
        break;
    }
  
    // Operadores lógicos
    if (idade >= 18 && status === "registrado") {
      mensagem += "Você tem acesso <strong>completo</strong> ao sistema.";
    } else {
      mensagem += "Você tem acesso <strong>limitado</strong> ao sistema.";
    }
  
    const divMensagem = document.getElementById("mensagem");
    divMensagem.innerHTML = mensagem;
    divMensagem.classList.remove("show");
    void divMensagem.offsetWidth; // força o reset da animação
    divMensagem.classList.add("show");
  }
  